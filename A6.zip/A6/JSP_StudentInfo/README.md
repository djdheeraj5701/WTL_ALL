# JSP_StudentInfo

same setup as ServletEbooks

Create and Read:

https://user-images.githubusercontent.com/62329500/162677384-2fa24b8c-15fd-462c-9073-ff06b7095326.png
https://user-images.githubusercontent.com/62329500/162677448-eeb07869-ff4c-41cd-9343-300d115e36f3.png


Update and Read:

https://user-images.githubusercontent.com/62329500/162677574-789a1ac0-416a-4850-a7f5-437bd85ab840.png
https://user-images.githubusercontent.com/62329500/162677594-d20bbce8-b0de-4ce2-ac23-52eb035b1dbd.png


Delete and Read:

https://user-images.githubusercontent.com/62329500/162677648-ec98a693-a9e0-478e-b5d4-0f9d418da86d.png
https://user-images.githubusercontent.com/62329500/162677675-30da3f70-4124-41ff-99de-4ccae4256189.png
