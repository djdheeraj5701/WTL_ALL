# ServletEbooks

https://youtube.com/playlist?list=PLSDyGb_vtanyU6PpouGX0fFLzQERN93gu

check this playlist for setup

https://user-images.githubusercontent.com/62329500/160794778-339a08cb-3eb6-46f4-87bc-5f68434bd227.png

https://user-images.githubusercontent.com/62329500/160794892-7367a5cf-c3f6-477f-8382-9de3860760ef.png

https://user-images.githubusercontent.com/62329500/160794981-e02451d7-df59-431d-a943-c6e5870196e2.png
